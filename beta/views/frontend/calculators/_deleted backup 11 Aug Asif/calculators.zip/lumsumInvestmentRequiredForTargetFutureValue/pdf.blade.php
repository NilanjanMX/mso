<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <title>Result</title>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        @include('frontend.calculators.common.pdf_style')
    </head>
    <body class="styleApril">
        
        @include('frontend.calculators.common.header')
        
        <main style="width: 806px;">
            <div style="padding: 0 0%;">
                <h1 style="color: #000;font-size:16px;margin-bottom:20px !important;text-align:center;">Lumpsum Investment @if(isset($clientname)) Proposal <br> For {{$clientname?$clientname:''}} @else Planning @endif</h1>
                <div class="roundBorderHolder">
                <table>
                    <tbody><tr>
                        <td style="width: 50%;text-align: left">
                            <strong>Target Amount</strong>
                        </td>
                        <td style="width: 50%;text-align: left;">
                            <span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format($amount)}}
                        </td>
                    </tr>
                    <tr>
                        <td style="width: 50%;text-align: left;">
                            <strong>Investment Period</strong>
                        </td>
                        <td style="width: 50%;text-align: left;">
                            {{$period?$period:0}} Years
                        </td>
                    </tr>
                    @if(!isset($interest2))
                        <tr>
                            <td style="width:50%;text-align: left">
                                <strong>Assumed Rate of Return </strong>
                            </td>
                            <td style="width:50%;text-align: left;">
                                {{$interest1?number_format($interest1, 2, '.', ''):0}} %
                            </td>
                        </tr>
                    @else
                        <tr>
                            <td style="width: 50%;text-align: left">
                                <strong>Assumed Rate of Return</strong>
                            </td>
                            <td style="padding:0; width: 50%;">
                                @if(isset($interest2))
                                    <table width="100%" style="margin: 0">
                                        <tbody>
                                        <tr>
                                            <td style="width: 50%;text-align: left">
                                                Scenario 1
                                            </td>
                                            <td style="width: 50%;text-align: left">
                                                {{$interest1?number_format($interest1, 2, '.', ''):0}} %
                                            </td>
                                        </tr>
                                        <tr>
                                            <td style="width: 50%;text-align: left;">
                                                Scenario 2
                                            </td>
                                            <td style="width: 50%;text-align: left;">
                                                {{$interest2?number_format((float)$interest2, 2, '.', ''):0}} %
                                            </td>
                                        </tr>
                                        </tbody>
                                    </table>

                                @else
                                    @ {{$interest1?number_format($interest1, 2, '.', ''):0}}% : <span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span>{{number_format(($amount*pow((1+($interest1/100)), $period)))}}
                                @endif
                            </td>
                        </tr>
                    @endif
                    
                    </tbody>
                </table>
                </div>
            </div>
            
            @if(!isset($interest2))
                <div style="padding: 0 20%;">
            @endif
            <h1 style="color: #000;font-size:16px;margin-bottom:5px !important;margin-top: 30px !important;text-align:center;">Initial Investment Required</h1>
            <div class="roundBorderHolder">
            <table class="table table-bordered text-center">
                <tbody>
                    @if(isset($interest2))
                        <tr>
                            <th style="width: 50%">
                                Scenario 1 @ {{$interest1?number_format($interest1, 2, '.', ''):0}} %
                            </th>
                            <th style="width: 50%">
                                Scenario 2 @ {{$interest1?number_format($interest2, 2, '.', ''):0}} %
                            </th>
                        </tr>
                        <tr>
                            <td style="width: 50%">
                                <strong><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format(($amount/pow((1+($interest1/100)), $period)))}} </strong>
                            </td>
                            <td style="width: 50%">
                                <strong><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format(($amount/pow((1+($interest2/100)), $period)))}} </strong>
                            </td>
                        </tr>
                    @else
                        <tr>
                            <td>
                                <strong>
                                    <span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format(($amount/pow((1+($interest1/100)), $period)))}}
                                </strong>
                            </td>
                        </tr>
                    @endif
                </tbody>
            </table>
            </div>
            
            
            @if($is_note == 1 && $note)
                <div style="padding: 0 0%;">
                    <h1 style="color: #000;font-size:16px;margin-bottom:20px !important;text-align:center;">Comment</h1>
                    <div class="roundBorderHolder">
                        <table>
                            <tbody>
                                <tr>
                                    <td>{{$note}}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            @endif
            @if(!isset($interest2))
                </div>
            @endif

            @php
                $note_data1 = \App\Models\Calculator_note::where('category','summery')->where('calculator','Lumsum_Investment_Required_for_Target_Future_Value')->first();
                if(!empty($note_data1)){
            @endphp
                {!!$note_data1->description!!}
            @php } @endphp
            Report Date : {{date('d/m/Y')}}
            
        </main>
        @include('frontend.calculators.common.watermark')
        @if($footer_branding_option == "all_pages")
            @include('frontend.calculators.common.footer')
        @endif
            
            @if(isset($report) && $report=='detailed')
                <div class="page-break"></div>
                
                @include('frontend.calculators.common.header')
                <main style="width: 806px;">

                <h1 class="bluebar" style="background:{{$city_color}}">Projected Annual Investment Value</h1>
                <div class="roundBorderHolder withBluebar">
                <table>
                    <tbody>
                    @if(isset($interest2))
                        <tr>
                            <th style="background:{{$address_color_background}}" rowspan="2">Year</th>
                            <th style="background:{{$address_color_background}}" colspan="2">Scenario 1  @ {{$interest1?number_format((float)$interest1, 2, '.', ''):0}} %</th>
                            <th style="background:{{$address_color_background}}" colspan="2">Scenario 2 @ {{$interest2?number_format((float)$interest2, 2, '.', ''):0}} %</th>
                        </tr>
                        <tr>
                            <th style="background:{{$address_color_background}}">Annual Investment</th>
                            <th style="background:{{$address_color_background}}">Year End Value</th>
                            <th style="background:{{$address_color_background}}">Annual Investment</th>
                            <th style="background:{{$address_color_background}}">Year End Value</th>
                        </tr>
                        @php
                            $previous_amount_int1 = $amount/pow((1+($interest1/100)), $period);
                            $previous_amount_int2 = $amount/pow((1+($interest2/100)), $period);
                        @endphp

                        @for($i=1;$i<=$period;$i++)
                            @php
                                $previous_amount_int1 = $previous_amount_int1+ ($previous_amount_int1* $interest1/100);
                                $previous_amount_int2 = $previous_amount_int2+ ($previous_amount_int2* $interest2/100);
                            @endphp
                            <tr>
                                <td>{{$i}}</td>
                                <td>
                                    @if($i==1)
                                        <span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format(($amount/pow((1+($interest1/100)), $period)))}}
                                    @else
                                        --
                                    @endif
                                </td>
                                <td><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format($previous_amount_int1)}}</td>
                                <td>
                                    @if($i==1)
                                        <span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format(($amount/pow((1+($interest2/100)), $period)))}}
                                    @else
                                        --
                                    @endif
                                </td>
                                <td><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format($previous_amount_int2)}}</td>
                            </tr>


                            @if($i%25==0 && $period>25 && $period>$i)
                                        </tbody>
                                    </table>
                                        </div>
                                        </main>
                                        @include('frontend.calculators.common.watermark')
                                        @if($footer_branding_option == "all_pages")
                                            @include('frontend.calculators.common.footer')
                                        @endif
                                        <div class="page-break"></div>
                                        
                                        @include('frontend.calculators.common.header')
                                        <main style="width: 806px;">
                                        <div class="roundBorderHolder withBluebar" style="margin-top: 30px !important;">
                                        
                                        <table>
                                            <tbody>
                                            <tr>
                                                <th style="background:{{$address_color_background}}" rowspan="2">Year</th>
                                                <th style="background:{{$address_color_background}}" colspan="2">Scenario 1  @ {{$interest1?number_format((float)$interest1, 2, '.', ''):0}} %</th>
                                                <th style="background:{{$address_color_background}}" colspan="2">Scenario 2 @ {{$interest2?number_format((float)$interest2, 2, '.', ''):0}} %</th>
                                            </tr>
                                            <tr>
                                                <th style="background:{{$address_color_background}}">Annual Investment</th>
                                                <th style="background:{{$address_color_background}}">Year End Value</th>
                                                <th style="background:{{$address_color_background}}">Annual Investment</th>
                                                <th style="background:{{$address_color_background}}">Year End Value</th>
                                            </tr>
                            @endif



                        @endfor
                    @else
                        <tr>
                            <th style="background:{{$address_color_background}}">Year</th>
                            <th style="background:{{$address_color_background}}">Annual Investment</th>
                            <th style="background:{{$address_color_background}}">Year End Value @ {{$interest1?number_format((float)$interest1, 2, '.', ''):0}} %</th>
                        </tr>
                        @php
                            $previous_amount_int1 = $amount/pow((1+($interest1/100)), $period);
                        @endphp

                        @for($i=1;$i<=$period;$i++)
                            @php
                                $previous_amount_int1 = $previous_amount_int1+ ($previous_amount_int1* $interest1/100);
                            @endphp
                            <tr>
                                <td>{{$i}}</td>
                                <td>
                                    @if($i==1)
                                        <span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format(($amount/pow((1+($interest1/100)), $period)))}}
                                    @else
                                        --
                                    @endif
                                </td>
                                <td><span style="font-family: DejaVu Sans; sans-serif;">&#8377;</span> {{custome_money_format($previous_amount_int1)}}</td>
                            </tr>


                            @if($i%25==0 && $period>25 && $period>$i)
                                            </tbody>
                                        </table>
                                        </div>
                                        </main>
                                        @include('frontend.calculators.common.watermark')
                                        @if($footer_branding_option == "all_pages")
                                            @include('frontend.calculators.common.footer')
                                        @endif
                                        <div class="page-break"></div>
                                        @include('frontend.calculators.common.header')
                                        <main style="width: 806px;">
                                        <div class="roundBorderHolder withBluebar">
                                        <table>
                                            <tbody>
                                            <tr>
                                                <th style="background:{{$address_color_background}}">Year</th>
                                                <th style="background:{{$address_color_background}}">Annual Investment</th>
                                                <th style="background:{{$address_color_background}}">Year End Value @ {{$interest1?number_format((float)$interest1, 2, '.', ''):0}} %</th>
                                            </tr>
                                            @endif
                        @endfor
                    @endif
                    </tbody>
                </table>
                </div>
                </main>
                @include('frontend.calculators.common.watermark')
                @if($footer_branding_option == "all_pages")
                    @include('frontend.calculators.common.footer')
                @endif
                
                
                @if($is_graph)
                    <div class="page-break"></div>
                    @include('frontend.calculators.common.header')
                    <main style="width: 806px;">
                    <h3 class="graphHeading">Detailed Graph View</h3>
                    <div style="text-align: center;" class="graphView">
                        <img src="{{$pie_chart2}}" style="width: 800px">
                    </div>
    
                    @php
                        $note_data2 = \App\Models\Calculator_note::where('category','cashflow')->where('calculator','Lumsum_Investment_Required_for_Target_Future_Value')->first();
                        if(!empty($note_data2)){
                    @endphp
                        {!!$note_data2->description!!}
                    @php } @endphp
                    
                    Report Date : {{date('d/m/Y')}}
                    
                    </main>
                    @include('frontend.calculators.common.watermark')
                    
                    @if($footer_branding_option == "all_pages" || !((isset($suggest) && session()->has('suggested_scheme_list'))))
                        @include('frontend.calculators.common.footer')
                    @endif
                @endif
            @endif

            @include('frontend.calculators.suggested.pdf')
        </main>
    </body>
</html>